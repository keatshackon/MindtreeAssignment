import java.util.*;

public class print_table {
	
	public static void main(String args[]) {
		
		Scanner input = new Scanner(System.in);
		
		int number = input.nextInt();
		
		for(int i = 1;i <= 12; i++) {
			System.out.print(number + " X " + i + " = "
						+ number * i + "\n");
		}
		input.close();
	}
}
